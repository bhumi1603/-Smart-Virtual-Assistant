
import requests
import wikipedia
import pyttsx3
import speech_recognition as sr
from decouple import config
from datetime import datetime
from random import choice
from pprint import pprint
import os
import psutil
import subprocess
from gtts import gTTS
import pywhatkit  # For WhatsApp messaging
from functions.os_ops import open_chrome  # Import function
from functions.os_ops import open_desktop, open_folder, open_file,open_or_create_folder, open_or_create_file,close_cmd
 # Import functions


from functions.online_ops import (
    find_my_ip, get_latest_news, get_random_advice, get_random_joke,
    get_trending_movies, get_weather_report, play_on_youtube,
    search_on_google, search_on_wikipedia, send_email, send_whatsapp_message
)
from functions.os_ops import (
    open_calculator, open_camera, open_cmd, open_notepad, open_discord
)
from utils import opening_text

# Load user settings
USERNAME = config('USER')
BOTNAME = config('BOTNAME')


# Initialize text-to-speech engine
engine = pyttsx3.init('espeak')  # Use 'espeak' for Linux
voices = engine.getProperty('voices')

engine.setProperty('voice', 'en+f3')

rate = engine.getProperty('rate')
engine.setProperty('rate', 150)  # Speech speed
engine.setProperty('volume', 2.5)  # Set volume

# Dictionary to track opened applications
opened_apps = {}

# Speak function
def speak(text):
    print(f"Assistant: {text}")
    tts = gTTS(text=text, lang='en', slow=False)
    tts.save("output.mp3")
    from playsound import playsound
    playsound("output.mp3")  # Install mpg321 if needed

    # Function to open applications
def open_application(app_name, command):
    try:
        process = subprocess.Popen(command, shell=True)  # Open app
        opened_apps[app_name] = process.pid  # Store PID
        speak(f"{app_name} has been opened.")
    except Exception as e:
        speak(f"Failed to open {app_name}. Error: {str(e)}")

# Function to close applications
# Function to close applications
def close_application(app_name):
    found = False  # Track if the app was found

    # Check if app was opened by the assistant
    if app_name in opened_apps:
        pid = opened_apps[app_name]
        try:
            os.kill(pid, 9)  # Force kill the process
            speak(f"{app_name} has been closed.")
            del opened_apps[app_name]  # Remove from tracking
            return
        except Exception as e:
            speak(f"Unable to close {app_name}. Error: {str(e)}")
    # Check all running processes if app was opened manually
    for process in psutil.process_iter(attrs=['pid', 'name']):
        process_name = process.info['name'].lower()

        if app_name.lower() in process_name or any(alias in process_name for alias in get_app_aliases(app_name)):
            try:
                os.kill(process.info['pid'], 9)  # Force kill the process
                speak(f"{app_name} has been closed successfully.")
                found = True
            except Exception as e:
                speak(f"Could not close {app_name}. Error: {str(e)}")

    if not found:
        speak(f"{app_name} is not running.")

def search_on_wikipedia(query):
    speak("Searching Wikipedia...")
    try:
        results = wikipedia.summary(query, sentences=4)
        speak("According to Wikipedia...")
        print(results)
        speak(results)
    except wikipedia.exceptions.DisambiguationError as e:
        speak("The topic you provided is ambiguous. Please be more specific.")
        print(f"Disambiguation Error: {e}")
    except wikipedia.exceptions.PageError:
        speak("Sorry, I couldn't find any results for your query.")
    except Exception as e:
        speak("An error occurred while searching Wikipedia.")
        print(f"Error: {e}")


# Function to define app aliases (common names)
def get_app_aliases(app_name):
    aliases = {
        "camera": ["camera", "webcam", "cheese", "microsoft camera"],
        "notepad": ["gedit", "mousepad", "kate", "leafpad", "xed", "pluma", "text editor"],
        "calculator": ["calculator", "calc"],
        "discord": ["discord"],
    }
    return aliases.get(app_name.lower(), [])  # Return aliases if available


# Greet the user
def greet_user():
    """Greets the user according to the time"""
    hour = datetime.now().hour
    if 6 <= hour < 12:
        speak(f"Good morning {USERNAME}!")
    elif 12 <= hour < 16:
        speak(f"Good afternoon {USERNAME}!")
    elif 16 <= hour < 19:
        speak(f"Good evening {USERNAME}!")
    speak(f"I am {BOTNAME}. How may I assist you?")

# Takes Input from User
def take_user_input():
    """Takes user input, recognizes it using Speech Recognition, and converts it into text"""
    
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print('Listening...')
        r.pause_threshold = 1
        r.adjust_for_ambient_noise(source, duration=1)  # Reduce background noise
        
        try:
            audio = r.listen(source, timeout=5, phrase_time_limit=7)
            print('Recognizing...')
            query = r.recognize_google(audio, language='en-in')
            print(f"User said: {query}")
            return query.lower()
        
        except sr.WaitTimeoutError:
            print("No speech detected. Try again.")
            return "None"
        except sr.UnknownValueError:
            print("Sorry, I could not understand.")
            return "None"
        except sr.RequestError:
            print("Internet issue. Check your connection.")
            return "None"

if __name__ == '__main__':
    greet_user()
    while True:
        query = take_user_input()

        if 'open notepad' in query:
            open_notepad()

        elif 'open discord' in query:
            open_discord()

        elif 'open command prompt' in query or 'open cmd' in query:
            open_cmd()

        elif 'open camera' in query:
            open_camera()

        elif 'open calculator' in query:
            open_calculator()

        # Close applications
        elif 'close notepad' in query:
            close_application("Notepad")

        elif 'close discord' in query:
            close_application("Discord")

        elif 'close calculator' in query:
            close_application("Calculator")

        elif 'close camera' in query:
            close_application("Camera") 

        elif 'exit' in query or 'shutdown' in query or 'close assistant' in query:
            speak("Shutting down. Goodbye!")
            exit()  # Exit the program

        elif 'ip address' in query:
            ip_address = find_my_ip()
            speak(f"Your IP Address is {ip_address}.")
            print(f"Your IP Address: {ip_address}")

        elif 'wikipedia' in query:
            speak("What do you want to search on Wikipedia?")
            search_query = take_user_input()
            results = search_on_wikipedia(search_query)
            speak(f"According to Wikipedia: {results}")
            print(results)

        elif 'youtube' in query:
            speak("What do you want to play on YouTube?")
            video = take_user_input()
            play_on_youtube(video)

        elif 'close app' in query:
            speak("Closing app...")
            youtube_closed = False  # Track if YouTube was found
        
            for process in psutil.process_iter(attrs=['pid', 'name']):
                if "chrome" in process.info['name'].lower() or "firefox" in process.info['name'].lower():
                    os.kill(process.info['pid'], 9)  # Kill the browser process
                    youtube_closed = True  # Mark YouTube as closed
        
            if youtube_closed:
                speak("app has been closed.")
            else:
                speak("app is not open.")

        elif 'search on google' in query:
            speak("What do you want to search on Google?")
            search_query = take_user_input()
            search_on_google(search_query)

    
        elif 'send' in query or 'email' in query:
            speak("Please enter the recipient's email.")
            receiver = input("Enter the recipient's email manually: ")

            if receiver:
                speak("What should be the subject?")
                subject = take_user_input()

                speak("What is the message?")
                message = take_user_input()

                if send_email(receiver, subject, message):
                    speak("Email has been sent successfully.")
                else:
                    speak("Failed to send the email.")
            else:
                speak("I couldn't get the recipient's email.")


        elif "whatsapp message" in query:
           speak("On what number should I send the message?")
           number = input("Enter the number (with country code, e.g., +91XXXXXXXXXX): ")

           speak("What should I say?")
           message = take_user_input()

           # Get the current time and send message 1 minute later
           now = datetime.now()
           hour = now.hour
           minute = now.minute + 1

           try:
               pywhatkit.sendwhatmsg_instantly(number, message)
               speak("Message will be sent shortly.")
           except Exception as e:
               print(f"Error: {e}")
               speak("Sorry, I failed to send the message.")


        elif 'joke' in query:
            joke = get_random_joke()
            speak(joke)
            pprint(joke)

        elif "advice" in query:
            advice = get_random_advice()
            speak(advice)
            pprint(advice)

        elif "trending movies" in query:
            movies = get_trending_movies()
            speak(f"Here are some trending movies:")
            for movie in movies:
                speak(movie)
                print(movie)


        elif 'weather' in query:
            speak("Which city's weather do you want to check?")
            city = take_user_input()
            weather, temperature, feels_like = get_weather_report(city)
            speak(f"The temperature is {temperature}, but it feels like {feels_like}. The weather is {weather}.")
            print(f"Weather: {weather}\nTemperature: {temperature}\nFeels like: {feels_like}")

        elif 'news' in query:
            news = get_latest_news()
            speak("Here are the latest news headlines.")
            for headline in news:
                speak(headline)
            pprint(news)

        elif "open chrome" in query:
            if open_chrome():
                speak("Google Chrome is now open.")
            else:
                speak("Failed to open Google Chrome.")

        elif "open desktop" in query:
            if open_desktop():
                speak("Desktop is now open.")
            else:
                speak("Failed to open Desktop.")
        
        elif "open folder" in query:
            speak("Please enter the folder path manually in the terminal.")
            folder_path = input("Enter the folder path: ")  # User manually inputs path
            if open_folder(folder_path):
                speak(f"Opened {folder_path}.")
            else:
                speak(f"Could not open {folder_path}.")
        
        elif "open file" in query:
            speak("Please enter the file path manually in the terminal.")
            file_path = input("Enter the file path: ")  # User manually inputs path
            if open_file(file_path):
                speak(f"Opened {file_path}.")
            else:
                speak(f"Could not open {file_path}.")
        elif 'create folder' in query:
            speak("Please enter the folder path manually in the terminal.")
            folder_path = input("Enter the folder path: ")
            open_or_create_folder(folder_path)

        elif 'create file' in query:
            speak("Please enter the file path manually in the terminal.")
            file_path = input("Enter the file path: ")
            open_or_create_file(file_path)
            
        elif 'close command prompt' in query or 'close terminal' in query:
            if close_cmd():
                speak("Command prompt has been closed.")
            else:
                speak("Command prompt is not running.")