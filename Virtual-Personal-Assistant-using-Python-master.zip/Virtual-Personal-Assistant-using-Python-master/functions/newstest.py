
import requests

NEWS_API_KEY = "your_news_api_key"  # Replace with your actual API key
BASE_URL = "https://newsapi.org/v2/top-headlines"

params = {"country": "in", "apiKey": NEWS_API_KEY}  # "in" for India news

response = requests.get(BASE_URL, params=params)
data = response.json()

print(data)  # Check full API response
