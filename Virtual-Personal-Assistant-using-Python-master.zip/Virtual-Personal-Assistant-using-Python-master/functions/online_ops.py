import requests
import wikipedia
import pywhatkit as kit
from email.message import EmailMessage
import smtplib
from decouple import config

NEWS_API_KEY = config("NEWS_API_KEY")
OPENWEATHER_APP_ID = config("OPENWEATHER_APP_ID")
TMDB_API_KEY = config("TMDB_API_KEY")
EMAIL = config("EMAIL")
PASSWORD = config("PASSWORD")


def find_my_ip():
    ip_address = requests.get('https://api64.ipify.org?format=json').json()
    return ip_address["ip"]


def search_on_wikipedia(query):
    results = wikipedia.summary(query, sentences=4)
    return results


def play_on_youtube(video):
    kit.playonyt(video)


def search_on_google(query):
    kit.search(query)


def send_whatsapp_message(number, message):
    kit.sendwhatmsg_instantly(f"+91{number}", message)


import smtplib
from email.message import EmailMessage

def send_email(receiver_email, subject, body):
    sender_email = "bhumibattula1603@gmail.com"  # Replace with your email
    sender_password = "ejcz siio olda mmlk"  # Replace with your Gmail App Password

    msg = EmailMessage()
    msg['From'] = sender_email
    msg['To'] = receiver_email
    msg['Subject'] = subject
    msg.set_content(body)

    try:
        # Use TLS with port 587
        with smtplib.SMTP("smtp.gmail.com", 587) as server:
            server.ehlo()
            server.starttls()  # Start TLS encryption
            server.login(sender_email, sender_password)
            server.send_message(msg)
        return True
    except Exception as e:
        print(f"Error: {e}")
        return False


def get_latest_news():
    API_KEY = "97407304fae54d67b1badbe5f575a263"  # Replace with your NewsAPI key
    BASE_URL = "https://newsapi.org/v2/top-headlines"
    
    params = {"country": "in", "apiKey": API_KEY}  # Change "in" to your country code if needed
    response = requests.get(BASE_URL, params=params)
    data = response.json()
    
    if "articles" in data:
        news_list = [article["title"] for article in data["articles"][:5]]
        return news_list
    else:
        return ["No news available."]



def get_weather_report(city):
    API_KEY = "04f5151bb970094ee2d54ae44141f279"  # Replace with your API key
    BASE_URL = "http://api.openweathermap.org/data/2.5/weather"
    
    params = {"q": city, "appid": API_KEY, "units": "metric"}  # Get data in Celsius
    response = requests.get(BASE_URL, params=params)
    data = response.json()
    
    if response.status_code == 200:
        weather = data["weather"][0]["description"]
        temperature = data["main"]["temp"]
        feels_like = data["main"]["feels_like"]
        return weather, f"{temperature}°C", f"{feels_like}°C"
    else:
        return "Weather data not available", "N/A", "N/A"

OMDB_API_KEY = " http://www.omdbapi.com/?i=tt3896198&apikey=7aacec82"  # Replace with your actual OMDB API Key
def get_trending_movies():
    
        url = f"https://www.omdbapi.com/?apikey={OMDB_API_KEY}&s=trending&type=movie"
        response = requests.get(url)
        data = response.json()

        if "Search" in data:
            movies = data["Search"][:5]  # Get top 5 movies
            movie_list = []
            for movie in movies:
                title = movie["Title"]
                year = movie["Year"]
                imdb_id = movie["imdbID"]
                movie_list.append(f"{title} ({year}) - IMDb ID: {imdb_id}")
            return movie_list
        else:
            return ["No trending movies found or API limit exceeded."]

def get_random_joke():
    headers = {
        'Accept': 'application/json'
    }
    res = requests.get("https://icanhazdadjoke.com/", headers=headers).json()
    return res["joke"]


import random

def get_random_advice():
    try:
        res = requests.get("https://api.adviceslip.com/advice", timeout=5)
        res.raise_for_status()
        data = res.json()
        return data['slip']['advice']
    except requests.exceptions.RequestException:
        offline_advice = [
            "Believe in yourself and all that you are.",
            "Mistakes are proof that you are trying.",
            "Keep going. Everything you need will come to you at the right time.",
            "Don't watch the clock; do what it does. Keep going."
        ]
        return random.choice(offline_advice)

