import os
import subprocess as sp
import sys
import subprocess
import psutil

# Define application paths for Windows (if needed in the future)
paths = {
    'notepad': "C:\\Program Files\\Notepad++\\notepad++.exe",
    'discord': "C:\\Users\\ashut\\AppData\\Local\\Discord\\app-1.0.9003\\Discord.exe",
    'calculator': "C:\\Windows\\System32\\calc.exe"
}

def open_notepad():
    if sys.platform == "win32":  # Windows
        os.startfile(paths['notepad'])
    else:  # Linux (Lenovo)
        sp.Popen(["gedit"])  # Opens Gedit (default text editor for Linux)

def open_discord():
    if sys.platform == "win32":
        os.startfile(paths['discord'])
    else:
        sp.Popen(["/snap/bin/discord", "--disable-gpu"])  # Opens Discord on Linux

def open_cmd():
    if sys.platform == "win32":
        os.system('start cmd')
    else:
        sp.Popen(["gnome-terminal"])  # Opens Terminal on Linux

def open_camera():
    if sys.platform == "win32":
        sp.run('start microsoft.windows.camera:', shell=True)
    else:
        sp.Popen(["cheese"])  # Opens Cheese (Linux webcam app)

def open_calculator():
    if sys.platform == "win32":
        sp.Popen(paths['calculator'])
    else:
        sp.Popen(["gnome-calculator"])  # Opens Calculator on Linux

def open_chrome():
    try:    
        subprocess.Popen("google-chrome", shell=True)  # For Linux (Ubuntu)
        # For Windows, use: subprocess.Popen("chrome.exe", shell=True)
        # For Mac, use: subprocess.Popen("open -a 'Google Chrome'", shell=True)
        return True
    except Exception as e:
        print(f"Failed to open Chrome: {e}")
        return False

def open_desktop():
    """Opens the Desktop folder."""
    desktop_path = os.path.expanduser("~/Desktop")  # For Linux/Mac
    # For Windows, use: desktop_path = os.path.join(os.environ["USERPROFILE"], "Desktop")
    subprocess.Popen(["xdg-open", desktop_path])  # For Linux
    # For Windows, use: os.startfile(desktop_path)
    return True

def open_folder(folder_path):
    """Opens a folder based on user input."""
    folder_path = os.path.expanduser(folder_path)  # Convert to absolute path
    if os.path.exists(folder_path) and os.path.isdir(folder_path):
        subprocess.Popen(["xdg-open", folder_path])  # Open folder
        return True
    return False

def open_file(file_path):
    """Opens a file based on user input."""
    file_path = os.path.expanduser(file_path)  # Convert to absolute path
    if os.path.exists(file_path) and os.path.isfile(file_path):
        subprocess.Popen(["xdg-open", file_path])  # Open file
        return True
    return False

def open_or_create_folder(folder_path):
    """
    Opens a folder if it exists, otherwise creates it first.
    Works on Linux (Ubuntu).
    """
    folder_path = os.path.expanduser(folder_path)  # Expand tilde (~) for home directory

    # Check if folder exists, if not, create it
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)
        print(f"Folder '{folder_path}' created successfully.")
    else:
        print(f"Folder '{folder_path}' already exists.")

    # Open folder
    subprocess.run(["xdg-open", folder_path]) 

def open_or_create_file(file_path):
    """
    Opens a file if it exists, otherwise creates it first.
    Works on Linux (Ubuntu).
    """
    file_path = os.path.expanduser(file_path)  # Expand tilde (~) for home directory

    # Extract the directory path
    folder = os.path.dirname(file_path)

    # Create the folder if it doesn't exist
    if folder and not os.path.exists(folder):
        os.makedirs(folder)
        print(f"Folder '{folder}' created for the file.")

    # Create the file if it doesn't exist
    if not os.path.exists(file_path):
        with open(file_path, "w") as file:
            file.write("")  # Create an empty file
        print(f"File '{file_path}' created successfully.")
    else:
        print(f"File '{file_path}' already exists.")

    # Open the file
    subprocess.run(["xdg-open", file_path])  

def close_cmd():
    """
    Closes the command prompt or terminal windows (in Linux).
    This targets 'gnome-terminal' or 'x-terminal-emulator'.
    """
    closed = False
    for proc in psutil.process_iter(['pid', 'name']):
        if proc.info['name'] in ['gnome-terminal', 'x-terminal-emulator', 'xterm', 'konsole']:
            try:
                os.kill(proc.info['pid'], 9)
                closed = True
            except Exception as e:
                print(f"Failed to close terminal: {e}")
    return closed