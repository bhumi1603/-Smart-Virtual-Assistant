import pyttsx3

# Initialize the text-to-speech engine
engine = pyttsx3.init('espeak')  

# Get available voices
voices = engine.getProperty('voices')

# Print all available voices
for index, voice in enumerate(voices):
    print(f"Voice {index}: {voice.name} - {voice.id}")
